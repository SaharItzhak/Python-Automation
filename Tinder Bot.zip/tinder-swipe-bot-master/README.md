to run:
 - download chromedriver, unzip, move to `/usr/local/bin` (mac os / linux)
 - `pip install selenium`

create a secrets.py file with variables:
``` 
 username = 'your_username'
 password = 'your_password'
```

please add more features to this, would be awesome to see what you can come up w

cheers

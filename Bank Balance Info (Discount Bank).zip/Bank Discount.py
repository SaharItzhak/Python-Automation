

import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


def get_balance():
    id = input("Please enter ID number \n")
    password = input("Please enter password \n")
    code = input("Please enter account code \n")

    driver = webdriver.Chrome(executable_path="C:\Webdrivers\chromedriver.exe")
    driver.get("https://start.telebank.co.il/apollo/core/templates/lobby/masterPage.html#/LOGIN_PAGE")
    driver.implicitly_wait(5)

    driver.find_element(By.ID, "tzId").send_keys(id)
    driver.find_element(By.ID, "tzPassword").send_keys(password)
    driver.find_element(By.ID, "aidnum").send_keys(code)
    driver.find_element(By.XPATH, "//*[@id='login-page']/div/div[1]/div[5]/div/a").click()
    delay = 3
    WebDriverWait(driver, delay).until(EC.presence_of_all_elements_located)
    time.sleep(2)

    driver.quit()


get_balance()


# Lists out all the files inside your folder
# Creates new folder
# Moves the files into the newly created folders based on filename extensions

import os
import shutil

# your path here
path = "C:/Users/Sahar/PycharmProjects/File Sorting/files folder"
kind = [".PNG", ".txt"]
folder_name = ['image', 'text']
f_names = os.listdir(path)
for i in folder_name:
    if not os.path.exists(path + '/' + i):
        os.makedirs(path + '/' + i)

for ii in f_names:
    for index in range(0, len(kind)):
        if kind[index] in ii and not os.path.exists(path + folder_name[index] + "/" + ii):
            shutil.move(path + '/' + ii, path + '/' + folder_name[index] + "/" + ii)
        # if ".txt" in ii and not os.path.exists(path + "image/" + ii):
        #     shutil.move(path + ii, path + "image/" + ii)



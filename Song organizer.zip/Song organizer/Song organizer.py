
# prettify song names and organize by number
# after moving number the the left and pad
# with zeroes

import os

# your songs folder path here
path = "C:/Users/Sahar/PycharmProjects/Song organizer/songs"
os.chdir(path)

for file in os.listdir(path):
    name, ext = os.path.splitext(file)
    title, course, num = name.split('-')
    title = title.strip()
    course = course.strip()
    num = num.strip()[1:].zfill(2)
    new_name = '{}-{}{}'.format(num, title, course)
    os.rename(file, new_name)




